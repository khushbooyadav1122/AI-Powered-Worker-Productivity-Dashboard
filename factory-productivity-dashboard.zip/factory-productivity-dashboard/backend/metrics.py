from sqlalchemy.orm import Session
from models import Event
from collections import defaultdict


def calculate_worker_metrics(db: Session):
    events = db.query(Event).order_by(Event.worker_id, Event.timestamp).all()

    worker_stats = defaultdict(lambda: {
        "working_time": 0,
        "idle_time": 0,
        "units_produced": 0
    })

    last_event = {}

    for event in events:
        wid = event.worker_id

        if wid in last_event:
            prev = last_event[wid]
            duration = (event.timestamp - prev.timestamp).total_seconds() / 60

            if prev.event_type == "working":
                worker_stats[wid]["working_time"] += duration
            elif prev.event_type == "idle":
                worker_stats[wid]["idle_time"] += duration

        if event.event_type == "product_count":
            worker_stats[wid]["units_produced"] += event.count

        last_event[wid] = event

    for wid, stats in worker_stats.items():
        total_time = stats["working_time"] + stats["idle_time"]
        stats["utilization"] = round(
            (stats["working_time"] / total_time) * 100, 2
        ) if total_time > 0 else 0

    return worker_stats
def calculate_workstation_metrics(db: Session):
    events = db.query(Event).order_by(Event.workstation_id, Event.timestamp).all()

    station_stats = defaultdict(lambda: {
        "occupancy_time": 0,
        "units_produced": 0
    })

    last_event = {}

    for event in events:
        sid = event.workstation_id

        if sid in last_event:
            prev = last_event[sid]
            duration = (event.timestamp - prev.timestamp).total_seconds() / 60

            if prev.event_type == "working":
                station_stats[sid]["occupancy_time"] += duration

        if event.event_type == "product_count":
            station_stats[sid]["units_produced"] += event.count

        last_event[sid] = event

    for sid, stats in station_stats.items():
        total_time = stats["occupancy_time"]
        stats["utilization"] = round((total_time / (8 * 60)) * 100, 2)  # 8 hr shift

    return station_stats


def calculate_factory_metrics(db: Session):
    worker_metrics = calculate_worker_metrics(db)
    workstation_metrics = calculate_workstation_metrics(db)

    total_production = sum(
        w["units_produced"] for w in worker_metrics.values()
    )

    avg_utilization = round(
        sum(w["utilization"] for w in worker_metrics.values()) / len(worker_metrics),
        2
    ) if worker_metrics else 0

    return {
        "total_production": total_production,
        "average_utilization": avg_utilization
    }
