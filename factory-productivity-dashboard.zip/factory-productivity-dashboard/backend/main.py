from fastapi import FastAPI
from database import engine
import models

app = FastAPI(title="Factory Productivity Dashboard")

models.Base.metadata.create_all(bind=engine)

@app.get("/")
def home():
    return {"status": "Backend is running successfully"}
from seed_data import run_seed
from fastapi import Depends
from sqlalchemy.orm import Session
from database import SessionLocal
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
@app.post("/seed-data")
def seed_data():
    run_seed()
    return {"status": "Dummy data seeded successfully"}
from schemas import EventCreate
from models import Event
from fastapi import HTTPException
@app.post("/events")
def ingest_event(event: EventCreate):
    db = SessionLocal()

    new_event = Event(
        timestamp=event.timestamp,
        worker_id=event.worker_id,
        workstation_id=event.workstation_id,
        event_type=event.event_type,
        confidence=event.confidence,
        count=event.count or 0
    )

    db.add(new_event)
    db.commit()
    db.refresh(new_event)
    db.close()

    return {"status": "Event ingested successfully"}
from metrics import calculate_worker_metrics
@app.get("/metrics/workers")
def get_worker_metrics():
    db = SessionLocal()
    data = calculate_worker_metrics(db)
    db.close()
    return data
from metrics import (
    calculate_workstation_metrics,
    calculate_factory_metrics
)
@app.get("/metrics/workstations")
def get_workstation_metrics():
    db = SessionLocal()
    data = calculate_workstation_metrics(db)
    db.close()
    return data


@app.get("/metrics/factory")
def get_factory_metrics():
    db = SessionLocal()
    data = calculate_factory_metrics(db)
    db.close()
    return data
