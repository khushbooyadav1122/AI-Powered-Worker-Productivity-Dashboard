from sqlalchemy.orm import Session
from database import SessionLocal
from models import Worker, Workstation, Event
import datetime
import random


def seed_workers(db: Session):
    workers = [
        Worker(worker_id="W1", name="Ramesh"),
        Worker(worker_id="W2", name="Suresh"),
        Worker(worker_id="W3", name="Amit"),
        Worker(worker_id="W4", name="Rahul"),
        Worker(worker_id="W5", name="Vikas"),
        Worker(worker_id="W6", name="Ankit"),
    ]
    db.add_all(workers)
    db.commit()


def seed_workstations(db: Session):
    stations = [
        Workstation(station_id="S1", name="Assembly"),
        Workstation(station_id="S2", name="Packaging"),
        Workstation(station_id="S3", name="Quality Check"),
        Workstation(station_id="S4", name="Welding"),
        Workstation(station_id="S5", name="Painting"),
        Workstation(station_id="S6", name="Inspection"),
    ]
    db.add_all(stations)
    db.commit()


def seed_events(db: Session):
    base_time = datetime.datetime.utcnow() - datetime.timedelta(hours=8)

    event_types = ["working", "idle", "product_count"]

    for i in range(200):
        event_time = base_time + datetime.timedelta(minutes=5 * i)

        event = Event(
            timestamp=event_time,
            worker_id=f"W{random.randint(1,6)}",
            workstation_id=f"S{random.randint(1,6)}",
            event_type=random.choice(event_types),
            confidence=round(random.uniform(0.8, 0.99), 2),
            count=random.randint(1, 5)
        )
        db.add(event)

    db.commit()


def run_seed():
    db = SessionLocal()
    seed_workers(db)
    seed_workstations(db)
    seed_events(db)
    db.close()
