# Factory Productivity Dashboard

## Overview
This project is an AI-powered factory productivity dashboard that ingests structured CCTV events
and displays worker, workstation, and factory-level productivity metrics.

## Architecture
AI Cameras → Backend API (FastAPI) → SQLite Database → Web Dashboard (HTML, CSS, JS)

## Backend
- FastAPI REST APIs
- Stores AI events
- Computes productivity metrics

## Frontend
- HTML, CSS, JavaScript
- Fetches metrics from backend
- Auto-refresh every 5 seconds

## Database Schema
- Workers (worker_id, name)
- Workstations (station_id, name)
- Events (timestamp, worker_id, station_id, event_type, confidence, count)

## Metrics Computed
### Worker Level
- Total working time
- Idle time
- Utilization %
- Units produced

### Workstation Level
- Occupancy time
- Utilization %
- Throughput

### Factory Level
- Total productive time
- Total units produced
- Average utilization

## Handling System Challenges
- Duplicate events: ignored using timestamp + worker_id checks
- Out-of-order events: sorted by timestamp
- Intermittent connectivity: backend supports batch ingestion

## Scalability
- Supports scaling from 5 to 100+ cameras
- Can be extended to multi-site deployment

## Future Improvements
- Model versioning
- Drift detection
- Automated retraining triggers

## Running Locally

### Using Docker
```bash
docker-compose up --build
